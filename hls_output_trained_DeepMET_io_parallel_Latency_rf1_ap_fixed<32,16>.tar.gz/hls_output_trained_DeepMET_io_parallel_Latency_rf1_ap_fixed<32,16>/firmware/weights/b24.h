//Numpy array shape [1]
//Min 3.417605638504
//Max 3.417605638504
//Number of zeros 0

#ifndef B24_H_
#define B24_H_

#ifndef __SYNTHESIS__
met_weight_bias_t b24[1];
#else
met_weight_bias_t b24[1] = {2.417605638504028};
#endif

#endif
